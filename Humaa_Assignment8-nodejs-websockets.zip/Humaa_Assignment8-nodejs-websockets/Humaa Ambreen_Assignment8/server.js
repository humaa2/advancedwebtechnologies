var app = require('express')(); //express package
var http = require('http').Server(app); //http package
var io = require('socket.io')(http); //socket package


// Return the auction page
app.get('/auction', function(req,res){
  res.sendFile(__dirname + '/auction.html');
});

// Return the bidder page
app.get('/bidder', function(req,res){
  res.sendFile(__dirname + '/bidder.html');
});

var pitem;
var nname;
var bids = 0;

var hbid; 
var sec;


io.on('connection', function(socket){

  socket.on("submitform", function(formdata)
  {

	//set the item
	pitem = formdata.item;
    // Set the bid
    bids = parseFloat(formdata.bid);	
	//set the item
	nname = formdata.newname;


    //Form submitted validation
    console.log("Form Submitted: " + JSON.stringify(formdata));
   
    // Broadcast the bid
    socket.broadcast.emit("deliverbid", formdata.bid);
	
	
	//Broadcast the item
	socket.broadcast.emit("deliveritem", formdata.item);
	
	
	//Broadcast the item
	socket.broadcast.emit("newitem", formdata.newname);
	
	var cd = 30;
	sec = setInterval(function() { 
		  cd--;
		  io.sockets.emit('sec', { cd: "Time Remaining: " + cd });

		  if (cd == 0) {
			  io.sockets.emit('sec', { cd: "Auction is over!"});
			  clearInterval(sec);
		  }
		}, 1000);	
	
	
});

	socket.on("newbidform", function(bdata)
	{
		
		hbid = parseFloat(bdata.newbid);
		
			if(hbid > bids){
				bids = hbid;
				
				io.sockets.emit('highBid', { name: bdata.itemname,
											totbid: hbid
										});
				
			}
			
			

	});
});

// Start the server
http.listen(3000, function(){
  console.log('listening on *:3000');
});

















