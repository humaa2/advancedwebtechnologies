// Use the slackbot package 
var Bot = require("slackbots");

//Load HTTP library 
var http = require("http");

// Helps us to build query strings
var querystring = require('querystring');

//Setting for the bot 
var settings = {
	
	token: 'xoxb-331805624791-aUbSyLw7Gtj0evI9UPapnrQJ',
	
	name: 'humii' 
	
}

//Creates the bot 
var bot = new Bot(settings);

//Start event occurs when bot is created 

bot.on('start',
	function()
	{
		
		bot.postMessageToChannel(
		'general',
		'Hello, I am the random joker robot!'
		
		);
		
	}

);


//Message event when bot has activity
bot.on(
		'message',
		
		function(data)
		{			
			
		console.log(data);
		
		//make sure the bot does not respond to itself 
		if(data.bot_id === "B9Q5WRNU9" ) return; 
		
		//only look at actual message 
		if(data.type !== "message") return; 
		
		
		if(data.text.substr(0,5) == "About"){
			bot.postMessageToChannel(
			'general',
			'The humii robot follows a comical entertainment theme. It provides random facts, lucky numbers, jokes and quotes'			
			
		);
		
		
			return; 
			
		}
	/////////////////////////JOKE SECTION//////////////////////////////////////////
	if (data.text.substr(0,4) == "Joke")
    {
    	// get the joke command
    	var word = data.text.substr(5,6);

        // send a joke based on the joke type!
    	if (word == "animal")
    	{
          bot.postMessageToChannel(
            'general',
            'What did the elephant want for his birthday?\n\n' +
            'A trunk full of gifts'
          );  		
    	}
    	else if (word == "people")
    	{
          bot.postMessageToChannel(
            'general',
            'What goes up but never comes down?\n\n' +
            'Your age!'
          );  		
    	}
    	else 
    	{
            bot.postMessageToChannel(
              'general',
              'What kind birthday cake do coffee lovers get?\n\n' +
              'Choco Latte!'
            );  		
    	}

    	return ;
    }
	///////////////////////////////
	
	
	if (data.text.substr(0,5) == "Quote")
    {
    	// get the quote command
    	var num = data.text.substr(6,7);

        // send a quote based on the quote type!
    	if (num == 1)
    	{
          bot.postMessageToChannel(
            'general',
            'A best friend is like a four leaf clover, hard to find and easy to keep\n' 
            
          );  		
    	}
    	else if (num == 2)
    	{
          bot.postMessageToChannel(
            'general',
            "The human body is 90% water, so basically we're cucumbers with anxiety\n'"  
          );  		
    	}
    	else 
    	{
            bot.postMessageToChannel(
              'general',
              "Chocolate doesn't ask silly questions, chocolate understands"
            );  		
    	}

    	return ;
    }
		
	
		//generate random number	
		if (data.text.substr(0,7) == "Random#")
    {
	  
	  var x = Math.floor((Math.random() * 10) + 1); 
      bot.postMessageToChannel(
        'general',
        'This is your lucky number ' + x
      );       

      // we return so that we don't output the default 
      // response to a message
      return ; 	
    }
	
	//Random Facts API 
		    if (data.text.substr(0,5) == "Fact ")
    {
     
	 //To account for number after fact 
      var facts = data.text.substr(5);
	  
  
      // The options for our API call
      var options = { 
        method: 'get',
        host: 'numbersapi.com',
        path: '/random/trivia?json'}; 

      // Handle the response to our API call
      callback = function(response) { 

      
        var str = ''; 
        response.on('data', function (chunk) { str += chunk; }); 
        
      
        response.on('end', function () 
        { 
          
		  //console.log(str);
	  
          var jsondata= JSON.parse(str);
		  console.log(jsondata);
		          
         bot.postMessageToChannel(
              'general',
              "Magic Number: " + 
                jsondata.number
               + " " +
              "Fact: " + 
                jsondata.text);  
		
        });
      }

      
      http.request(options, callback).end();

      return ;
    }
		
		
		
		
		//default message to send back 
		bot.postMessageToChannel(
		'general',
		'What did you say? Please repeat yourself'
		
		);
		
		
		
		
		
		}
		
);
		












