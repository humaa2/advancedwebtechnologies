<!DOCTYPE html>
<html>
  <head>
    <title>Student Payment Form</title>
    <style>

      input[type=text] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
      }

      select {
        width: 100%;
        padding: 16px 20px;
        border: none;
        border-radius: 4px;
        background-color: #f1f1f1;
        font-size:14px;
        margin-top: 7px;
        margin-bottom: 7px;

      }

      input[type=button], input[type=submit], input[type=reset] {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 16px 32px;
        text-decoration: none;
        margin: 4px 2px;
        cursor: pointer;
      }

      .success {
        font-size: 20px;
        color: green;
      }

      .error {
      	font-size: 20px;
      	color: red;
      }

    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  </head>
<body>
  
  <!-- Form solution code here !-->
  <h1>Student Payment Form</h1>

<form action="form.php" method="post" id="pform">

					First Name <br>
   <input type="text" name="ftname" id="fname"> <br>
   
					Last Name <br>
    <input type="text" name="ltname" id="lname"> <br>
	
					Student ID <br>
    <input type="text" name="sid" id="id"> <br>
	
					Tuition <br>
    <input type="text" name="tuition" id="tuitionp"> <br>
    
	
		Payment Method <br>
		<select name="payment" id="paymentm">
					<option value="bitcoin">Bit Coin</option>
					<option value="debit">Debit</option>
					<option value="credit">Credit</option>
		</select> <br>

    <input type="submit" value="SUBMIT">
    <input type="button" value="RANDOM" id="rand">
    <input type="button" id="log" value="LOG">
	
</form>

  <br /> 

<?php 


	 $ftname=$_POST['ftname'];
	 $ltname=$_POST['ltname'];
	 $sid=$_POST['sid'];
	 $tuition=$_POST['tuition'];
	 $payment=$_POST['payment'];	 
	 $success = true;
	 
					
					if($_SERVER["REQUEST_METHOD"] == "POST")
					{
						//first name check
						if(strlen($ftname)<2)
						{
							$success=false;
							echo "<span class='error'>First name must be 2 or more characters in length<br></span>";
						
						}
						
						//last name check
						if(strlen($ltname)<3||strlen($ltname)>12)
						{
							$success=false;
							echo "<span class='error'>Last name must be between 3 and 12 characters in length<br></span>";
							
						}
						
						//student id check
						if(strlen($sid)!=9)
						{
							$success=false;
							echo "<span class='error'>Student id must be exactly 9 characters in length<br></span>";
							
							
						}
						
						//tuition amount check
						if($tuition < 2000 || $tuition > 10000)
						{
							
						$success = false;
						echo "<span class='error'>Tuition must be between 2000 and 10000<br></span>";
					
						}
						
		if($success)
		{
					echo "<span class='success'>Payment successful!</span>";
        		
        $line = array($ftname, $ltname, $sid, $tuition, $payment); 
        $doc = fopen("log.txt", "a+"); 
        fputcsv($doc, $line); 
        fclose($doc);
									
		}	 
	 
 }
 

?>

<script>

  // JavaScript solution code here
  $(document).ready(function()
  {
	  
	  $("#log").click
	 (
		function()
		{
			window.location.href = 'log.txt';			
		} 
	 );
	 
	 $("#rand").click
	 (
		function()
		{
		 $.post("rangen.php", {},
		 function(data){
			 $("#fname").val(data["firstname"]);
			 $("#lname").val(data["lastname"]);
			 $("#id").val(data["studentid"]);
			 $("#tuitionp").val(data["tuition"]);
			 $("#paymentm").val(data["method"]);
			 
		 }, "json");
		 
		}
	 );
		
});
  

</script>
</body>
</html>


