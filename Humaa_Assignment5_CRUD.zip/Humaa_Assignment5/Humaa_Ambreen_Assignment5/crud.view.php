<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Phonebook Directory: Assignment 5</title>

  <!-- Bootstrap -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

</head>
<body>

	<div class="container">
	

		<h1>Phonebook Table</h1>

<div class="container">
<h3>Sort By</h3>
  <div class="btn-group btn-group-justified">
	<a href="crud.ctrl.php?act=orderByFirstName" class="btn btn-info btn-lg" role="button">First Name</a>
	<a href="crud.ctrl.php?act=orderByPhone" class="btn btn-info btn-lg" role="button">Phone Number</a>
	<a href="crud.ctrl.php?act=orderByMC" class="btn btn-info btn-lg" role="button">MC</a>    
  </div>
</div>
<br>



<table class="table table-striped">
    <tr>
        <th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Phone Number</th>
        <th>Email Address</th>
        <th>Location</th>
        <th>MC</th>
        <th>Position</th>
        <th>Department</th>
		<th>Update</th>
        <th>Delete</th>
		
    </tr>
    <?foreach ($TPL["phonebook"] as $phonedata) { ?>
        <tr>
            <td><?= $phonedata["id"] ?></td>
            <td><?= $phonedata["fname"] ?></td>
            <td><?= $phonedata["lname"] ?></td>
            <td><?= $phonedata["phone"] ?></td>
            <td><?= $phonedata["email"] ?></td>
            <td><?= $phonedata["location"] ?></td>
            <td><?= $phonedata["mc"] ?></td>
            <td><?= $phonedata["pos"] ?></td>
            <td><?= $phonedata["dept"] ?></td>				
			
					<td style="text-align: center">
                        <div class="btn-toolbar">
                            <div class="btn-group">
								<a data-toggle="modal" role="button" class="btn btn-success myModal" 
								data-id="<?php echo $phonedata["id"];?>"
								data-first_name="<?php echo $phonedata["fname"];?>" 
								data-last_name="<?php echo $phonedata["lname"];?>"
								data-phone="<?php echo $phonedata["phone"];?>"
								data-email="<?php echo $phonedata["email"];?>"
								data-location="<?php echo $phonedata["location"];?>"
								data-mc="<?php echo $phonedata["mc"];?>"
								data-pos="<?php echo $phonedata["pos"];?>"
								data-dept="<?php echo $phonedata["dept"];?>">Update</a>
								
								
            <td><a href="crud.ctrl.php?act=delete&id=<?= $phonedata["id"] ?>">DELETE</a></td>
			
        </tr>
        <? } ?>
</table>



<div class="container">
  <h2>Add Phonebook Entry</h2>
  <form action="crud.ctrl.php?act=insert" method="post">
  
    <div class="form-group">
      <label for="fname">First Name: </label>
      <input type="text" class="form-control" name="fname" placeholder="Enter First Name">
    </div>
	
    <div class="form-group">
      <label for="lname">Last Name: </label>
      <input type="text" class="form-control" name="lname" placeholder="Enter Last Name">
    </div>
	
	<div class="form-group">
      <label for="phone">Phone Number: </label>
      <input type="text" class="form-control" name="phone" placeholder="Enter Phone Number">
    </div>
	
	<div class="form-group">
      <label for="email">Email Address: </label>
      <input type="text" class="form-control" name="email" placeholder="Enter Email Address">	  
    </div>
	
	<div class="form-group">
      <label for="location">Location: </label>
      <input type="text" class="form-control" name="loc" placeholder="Enter Location">	  
    </div>
	
	<div class="form-group">
      <label for="mc">MC: </label>
      <input type="text" class="form-control" name="mc" placeholder="Enter MC">	  
    </div>
	
	<div class="form-group">
      <label for="pos">Position: </label>
      <input type="text" class="form-control" name="pos" placeholder="Enter Position">	  
    </div>
	
	<div class="form-group">
      <label for="dept">Department: </label>
      <input type="text" class="form-control" name="dept" placeholder="Enter Department">	  
    </div> 
   
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>


<br>
<br>
	
		  <div id = "myModal" class = "modal fade" role = "dialog">
			<div class="modal-dialog">			
			  <div class="modal-content">
				<div class="modal-header">
				  <button type="button" class="close" data-dismiss="modal">&times;</button>				  
				  <h1 class="modal-title">Phonebook Entry Update</h1>
				</div>
				<div class="modal-body">
				
					<form class="form-horizontal" role="form" method="post" action="crud.ctrl.php?act=update">
						<div class="form-group">
							<label for="fname" class="col-md-12">First Name</label>
							<div class="col-md-12">
								<input type="hidden" class="form-control" id="phonebkid" name="phoneid"> 
								<input type="text" class="form-control" id="firstname1" name="fname1" placeholder="First Name">
							</div>
						</div>
						<div class="form-group">
							<label for="lname" class="col-md-12">Last Name</label>
							<div class="col-md-12">
								<input type="text" class="form-control" id="lastname1" name="lname1" placeholder="Last Name">
							</div>
						</div>
						<div class="form-group">
							<label for="phone" class="col-md-12">Phone Number</label>
							<div class="col-md-12">
								<input type="tel" class="form-control" id="phonenum1" name="phone1" placeholder="Phone">
							</div>
						</div>
						<div class="form-group">
							<label for="email" class="col-md-12">Email Address</label>
							<div class="col-md-12">
								<input type="email" class="form-control" id="emailadd1" name="email1" placeholder="example@domain.com" value="">
							</div>
						</div>
						<div class="form-group">
							<label for="loc" class="col-md-12">Location</label>
							<div class="col-md-12">
								<input type="text" class="form-control" id="location1" name="loc1" placeholder="location" value="">
							</div>
						</div>
						<div class="form-group">
							<label for="mc" class="col-md-12">MC</label>
							<div class="col-md-12">
								<input type="number" class="form-control" id="m_c" name="mc1" placeholder="MC" value="">
							</div>
						</div>
						<div class="form-group">
							<label for="pos" class="col-md-12">Position</label>
							<div class="col-md-12">
								<input type="text" class="form-control" id="position1" name="pos1" placeholder="POS" value="">
							</div>
						</div>
						<div class="form-group">
							<label for="dept" class="col-md-12">Department</label>
							<div class="col-md-12">
								<input type="text" class="form-control" id="department1" name="dept1" placeholder="dept" value="">
							</div>
						</div>
						
						<div class="form-group">
							<div class="col-md-12">
								<input id="submit" name="submit" type="submit" value="UPDATE" class="btn btn-primary">
							</div>
						</div>
					</form>
				</div>
			  </div>
			</div>
	      </div>
	</div>

	<script>

	$(document).ready(function(){
		$(document).on('click', '.myModal', function(){
			var id=$(this).data('id');
			var fname=$(this).data('first_name');
			var lname=$(this).data('last_name');
			var phone=$(this).data('phone');
			var email=$(this).data('email');
			var location=$(this).data('location');
			var mc=$(this).data('mc');
			var pos=$(this).data('pos');
			var dept=$(this).data('dept');

	 
			$('#myModal').modal('show');
			$('#phonebkId').val(id);
			$('#firstname1').val(fname);
			$('#lastname1').val(lname);
			$('#phonenum1').val(phone);
			$('#emailadd1').val(email);
			$('#location1').val(location);
			$('#m_c').val(mc);
			$('#position1').val(pos);
			$('#department1').val(dept);
		});
	});
	
	</script>
	




 <h3>TPL Array Dump</h3>
<pre><? var_dump($TPL) ?></pre>



    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>