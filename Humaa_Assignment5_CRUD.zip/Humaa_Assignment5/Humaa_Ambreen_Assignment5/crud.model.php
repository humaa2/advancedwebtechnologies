<?php

function getPhonebook($conn) 
{
  try {
	
    $stmt = $conn->prepare("SELECT * FROM phonebook");
	$stmt->execute();
	
	$results = array();
    while ($row = $stmt->fetch())
    {
      $results[] = $row;
    }	
	return $results;
  }
  
  catch(PDOException $e)
  {

	$logfile = fopen("errorlog.txt", "a") or die("Unable to open file!");

	fwrite($logfile, "getPhonebook failed: " . $e->getMessage() . "\n");
	fclose($logfile);

	exit();
  }	
}

function getPhonebookOrderByFirstName($conn) 
{
  try {
	
    $stmt = $conn->prepare("SELECT * FROM phonebook ORDER BY fname");
	$stmt->execute();
	
	$results = array();
    while ($row = $stmt->fetch())
    {
      $results[] = $row;
    }	
	return $results;
  }
  
  catch(PDOException $e)
  {

	$logfile = fopen("errorlog.txt", "a") or die("Unable to open file!");

	fwrite($logfile, "getPhonebookOrderByFirstName failed: " . $e->getMessage() . "\n");
	fclose($logfile);

	exit();
  }	
}

function getPhonebookOrderByPhone($conn) 
{
  try {
	
    $stmt = $conn->prepare("SELECT * FROM phonebook ORDER BY phone");
	$stmt->execute();
	
	$results = array();
    while ($row = $stmt->fetch())
    {
      $results[] = $row;
    }	
	return $results;
  }
  
  catch(PDOException $e)
  {

	$logfile = fopen("errorlog.txt", "a") or die("Unable to open file!");

	fwrite($logfile, "getPhonebookOrderByPhone failed: " . $e->getMessage() . "\n");
	fclose($logfile);
	exit();
  }	
}

function getPhonebookOrderByMC($conn) 
{
  try {
	
    $stmt = $conn->prepare("SELECT * FROM phonebook ORDER BY mc");
	$stmt->execute();
	
	$results = array();
    while ($row = $stmt->fetch())
    {
      $results[] = $row;
    }	
	return $results;
  }
  
  catch(PDOException $e)
  {

	$logfile = fopen("errorlog.txt", "a") or die("Unable to open file!");

	fwrite($logfile, "getPhonebookOrderByMC failed: " . $e->getMessage() . "\n");
	fclose($logfile);
	exit();
  }	
}


function deletePhonebook($conn, $phoneid) 
{
  try {
    $stmt = $conn->prepare("DELETE FROM phonebook WHERE id=?");
	$stmt->execute([$phoneid]);
  }
  catch(PDOException $e)
  {

	$logfile = fopen("errorlog.txt", "a") or die("Unable to open file!");

	fwrite($logfile, "deletePhonebook failed: " . $e->getMessage() . "\n");
	fclose($logfile);
	exit();
  }		
}

function insertPhonebook($conn, $fname, $lname, $phone, $email, $location, $mc, $pos, $dept) 
{
  try {

	$stmt = $conn->prepare("INSERT INTO phonebook " .
	                      "(id,fname,lname,phone,email,location,mc,pos,dept) VALUES " . 
						  "(?, ?, ?, ?, ?, ?, ?, ?, ?)");
	$stmt->execute(["null", $fname, $lname, $phone, $email, $location, $mc, $pos, $dept]);

  }

  catch(PDOException $e)
  {

	$logfile = fopen("errorlog.txt", "a") or die("Unable to open file!");

	fwrite($logfile, "insertPhonebook failed: " . $e->getMessage() . "\n");
	fclose($logfile);
	exit();
  }		
}
function updatePhonebook($conn, $phonebookid, $fname, $lname, $phone, $email, $location, $mc, $pos, $dept) 
{
  try {

	$stmt = $conn->prepare("UPDATE phonebook SET " .
	                      "fname=?, lname=?, phone=?, email=?, location=?, mc=?, pos=?, dept=? " . 
						  "WHERE id=?");
	$stmt->execute([$fname, $lname, $phone, $email, $location, $mc, $pos, $dept, $phonebookid]);
	

  }

  catch(PDOException $e)
  {

	$logfile = fopen("errorlog.txt", "a") or die("Unable to open file!");

	fwrite($logfile, "updatePhonebook failed: " . $e->getMessage() . "\n");
	fclose($logfile);
	exit();
  }		
}

?>