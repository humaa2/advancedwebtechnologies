<?php

include "dbheader.php";

include "crud.model.php";

$TPL = array();

$TPL["phonebook"] = getPhonebook($conn);

switch ($_REQUEST["act"]) { 
   
  case "delete":

    $phoneid = $_REQUEST["id"];
    deletePhonebook($conn, $phoneid);  
	$TPL["phonebook"] = getPhonebook($conn);
   
    break;

  case "insert":
  
    insertPhonebook($conn,
	          $_REQUEST["fname"],
	          $_REQUEST["lname"],
			  $_REQUEST["phone"],
			  $_REQUEST["email"],
			  $_REQUEST["loc"],
			  $_REQUEST["mc"],
			  $_REQUEST["pos"],
			  $_REQUEST["dept"]);
	$TPL["phonebook"] = getPhonebook($conn);

	break;

  case "update":
  
    updatePhonebook($conn,
			  $_REQUEST["phoneid"],
	          $_REQUEST["fname1"],
	          $_REQUEST["lname1"],
			  $_REQUEST["phone1"],
			  $_REQUEST["email1"],
			  $_REQUEST["loc1"],
			  $_REQUEST["mc1"],
			  $_REQUEST["pos1"],
			  $_REQUEST["dept1"]);
	$TPL["phonebook"] = getPhonebook($conn);

	 break;


   case "orderByFirstName":

		$TPL["phonebook"] = getPhonebookOrderByFirstName($conn);
  
    break;

   case "orderByPhone":

		$TPL["phonebook"] = getPhonebookOrderByPhone($conn);
  
    break;

   case "orderByMC":

		$TPL["phonebook"] = getPhonebookOrderByMC($conn);
  
    break;
   
  default:	
	
}

// view with our user interface
include "crud.view.php";

?>