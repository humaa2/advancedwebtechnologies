<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['assetsPath'] = "http://localhost/assets/";

