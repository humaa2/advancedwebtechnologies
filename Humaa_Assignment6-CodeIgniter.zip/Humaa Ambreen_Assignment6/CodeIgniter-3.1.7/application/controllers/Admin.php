<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	
  var $TPL;
 

  public function __construct()
  {
    parent::__construct();
    // Your own constructor code

    // is the user logged in or not?
    $this->TPL["loggedin"] = true;

    // which page is active?
    $this->TPL['active'] = array('home' => false,
                                 'members'=>false,
                                 'admin' => true,
                                 'login'=>false);

  }
  
   public function getAllusers()
    {
      // get all the users from the users table
      $query = $this->db->query("SELECT * FROM usersas6");

      $this->TPL["userresults"] = array();
      foreach ($query->result() as $row)
      {
          $this->TPL["userresults"][] = $row;
      }

    }     
  

  public function index()
  {
	$this->getAllusers();
    $this->template->show('admin', $this->TPL);
  }
  
  
   public function deleteuser($id)
    {
    	// delete the user from the user database with id $id
    	$this->db->query("DELETE FROM usersas6 WHERE compid=$id");

        $this->getAllusers();

    	$this->template->show('admin', $this->TPL);
    }
	
	 public function addUser(){
        
        $username = $_POST['username'];
        $password = $_POST['password'];
        $accesslevel = $_POST['accesslevel'];
		
        
            $data = array(
                'username' => $username,
                'password' => $password,
                'accesslevel' => $accesslevel
            );

            $this->db->insert('usersas6', $data); 
        }
    }
	
		

