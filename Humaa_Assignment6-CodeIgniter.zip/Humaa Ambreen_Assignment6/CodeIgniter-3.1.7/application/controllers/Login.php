<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    var $TPL;

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code

        // is the user logged in or not?
        $this->TPL["loggedin"] = false;

        // which page is active?
        $this->TPL['active'] = array('home' => false,
            'members'=>false,
            'admin' => false,
            'login'=>true);
		//$this->load->library('session');
		
		
		/*
					$config['acl'] =  array(

								'home' => array(

								'public' =>true, 'member' => true, 'admin' => true),                       

								'members' => array(

								'public' => false, 'member' => true, 'admin' => true),                       

								'admin' => array(

								'public' => true, 'member' => false, 'admin' => true),                       

								'loggedin' => array(

								'public' => true, 'member' => true, 'admin' => true)                      

					);
*/
	}

    public function index()
    {
        $this->template->show('login', $this->TPL);
    }

    public function register(){
     
	 
	$username = $this->input->post("username");
	$password = $this->input->post("password");
	
	$this->db->select("*");
	
	$this->db->from("usersas6");
	
	$this->db->where("username",$username);
	$this->db->where("password",$password);
	
	$query = $this->db->get();


        foreach ($query->result() as $row){
            if($username == $row->username && $password == $row->password){
				
				/*$userdata = array(
				'username'  => $username,
				'password'     => $password,
				'loggedin' => true
			     );
				 $this->session->set_userdata($userdata); */         

                $this->TPL["loggedin"] = true;
				

                if($row->accesslevel == 'admin'){ 
					
                    redirect('/Admin/');
                }
                elseif ($row->accesslevel == 'member'){
										
                    redirect('/Members/');
                }
            }
            else{
               
                echo "Incorrect entries, please enter correct information" . '<br>';
            }
        }
    }
	
	public function logout(){
		
		//$this->session->unset_userdata($userdata);
		
		redirect('/login/');
		
	}
	
	
	
	
}



















