<footer class="footer">
 <p >Copyright 2018</p>
/*
<br>

<pre>
<? print_r($_SESSION); ?>
</pre>
*/
<pre>
<? print_r($_COOKIE); ?>
</pre>

 </footer>

</body>
</html>

