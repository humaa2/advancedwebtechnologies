<div id="body">

      <table>
      <tr>
        <td>Company ID</td>
        <td>User name</td>
        <td>Password</td>
        <td>Access Level</td>
		<td>delete</td>

      </tr>
      <?php foreach ($userresults as $user) { ?>
        <tr>
          <td><?= $user->compid ?></td>
          <td><?= $user->username ?></td>
          <td><?= $user->password ?></td>
          <td><?= $user->accesslevel ?></td>   
		  <td><a href="<?= site_url("/Admin/deleteuser/".$user->compid)?>">D</a></td>
		
		  
      </tr>      
      <?php } ?>
      </table>
	
	
	<h3>Add User Form</h3>
<form action="/CodeIgniter-3.1.7/index.php/Admin/addUser/" method="post">
    Username: <input type="text" name="username" placeholder="Username"><br>
    Password: <input type="text" name="password" placeholder="Password"><br>
    Access Level: <input type="text" name="accesslevel" placeholder="Access Level"><br>
    <input type="submit" value="Submit">
</form>
	
 
	  
	  

	</div>
