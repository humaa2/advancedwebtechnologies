<!DOCTYPE html>
<html lang="en">
 <head>
 <title>User Authentication Application</title>
 <link rel="stylesheet" type="text/css" href="<?= assetUrl(); ?>css/main.css">
 </head>
 <body>


<img src="<?= assetUrl() ?>img/headerlogo.png">