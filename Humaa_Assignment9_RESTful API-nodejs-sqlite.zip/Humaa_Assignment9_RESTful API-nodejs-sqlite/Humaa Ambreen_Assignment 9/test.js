var http = require('http');

var options = {
  method: 'put',
  host: 'localhost',
  port: '3000',
  path: '/api'
}

var deleteoptions = {
  method: 'delete',
  host: 'localhost',
  port: '3000',
  path: '/api/2'
}

deletegetcallback = function(response)
{
  var str = "";
  response.on('data', function(chunk) { str += chunk;});
  response.on('end', function(){
    console.log(str);
	
	http.request(getoptions,getcallback).end();
	
	
  });
}


var getoptions = {
  method: 'get',
  host: 'localhost',
  port: '3000',
  path: '/api'
}

getcallback = function(response)
{
  var str = "";
  response.on('data', function(chunk) { str += chunk;});
  response.on('end', function(){
    console.log(str);
  });
}

callback = function(response)
{
  var str = "";
  response.on('data', function(chunk) { str += chunk; });
  response.on('end', function()
  {
    console.log(str);

    // fire off the next request
    http.request(deleteoptions,deletegetcallback).end();

  });
}

var putdata =
{ "color":[
			{"item" : "Green", "description" : "Fresh color of mother nature", "price" : "780"},
			{"item" : "Blue", "description" : "Cool color of the sapphire sea", "price" : "460"},
			{"item" : "Purple", "description" : "Royal color of vintage fashion", "price" : "820"}	
		  ]
}


myreq = http.request(options, callback);
myreq.write(JSON.stringify(putdata));
myreq.end();




