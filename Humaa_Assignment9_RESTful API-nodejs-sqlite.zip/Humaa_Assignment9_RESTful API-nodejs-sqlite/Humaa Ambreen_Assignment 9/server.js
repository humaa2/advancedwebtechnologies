var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("colors.db");
var express = require('express');
var app = express();


db.serialize(function(){

  db.run("DROP TABLE IF EXISTS Collection");
  db.run("CREATE TABLE Collection (item TEXT, description TEXT, " +
  	     "price INTEGER)");

  // insert initial records into the table
  /*
  var stmt = db.prepare("INSERT INTO Collection VALUES (?,?,?)");
  stmt.run("Green", "Fresh color of mother nature", "780");
  stmt.run("Blue", "Cool color of the sapphire sea", "460");
  stmt.run("Purple", "Royal color of vintage fashion", "820");
  stmt.finalize();
  */
 

});

//A GET request to /api should return the entire collection of data as a JSON array in the body of the response.

app.get("/api",
  function(req,res)
  {
    console.log("GET REQUEST RECEIVED");

  	db.all("SELECT rowid as id, item, description, price FROM Collection",
  		   function(err, results)
  		   {
             // send debug info to console
             console.log(JSON.stringify(results));
  
             // send back table data as JSON data
             res.send(JSON.stringify(results));
  		   });
  });
  

  
//A GET request to /api/id should return the item with the supplied id as JSON data in the body of the response

  
  app.get("/api/:id",
  function(req,res)
  {
    console.log("GET REQUEST RECEIVED");

  	db.all("SELECT rowid as id, item, description, price FROM Collection Where rowid=" + req.params.id,
  		   function(err, results)
  		   {
             console.log(JSON.stringify(results));
             res.send(JSON.stringify(results));
  		   });
  });
  
 
  
/*A PUT request to /api should replace the entire collection with the collection provided as 
a JSON array in the body of the request. The API should return the response “COLLECTION UPDATED”.*/
  
  
  app.put("/api",
  function(req,res)
  {
  	console.log("PUT REQUEST RECEIVED");

    var str = "";
    req.on("data", function(chunk) { str += chunk;});
    req.on("end", function() { 
 
      var reqObj = JSON.parse(str);

      console.log(reqObj);


      db.serialize(function() {

        var stmt = db.prepare("INSERT INTO Collection (item, description, price)  VALUES (?,?,?)");

		for(i = 0; i < reqObj.color.length; i++){

			stmt.run(reqObj.color[i].item,
        	         reqObj.color[i].description,
        	         reqObj.color[i].price);
		}

        stmt.finalize();

        res.send("ITEM UPDATED");
      });

    });

  });
 
 /* A PUT request to /api/id should replace the item in the collection with the supplied id
with the item provided as JSON data in the body of the request. The API should return
the response “ITEM UPDATED”. */
  
app.put("/api/:id",
  function(req,res)
  {
  	console.log("PUT REQUEST RECEIVED");

    var str = "";
    req.on("data", function(chunk) { str += chunk;});
    req.on("end", function() { 
 
      var reqObj = JSON.parse(str);

      console.log(str);

      db.serialize(function() {
        var stmt = db.prepare("UPDATE Collection set item=(?), " +
        	                    "description=(?), price=(?) WHERE " +
        	                    "rowid=" + req.params.id);
        stmt.run(reqObj.item,
        	     reqObj.description,
        	     reqObj.price);

        stmt.finalize();

        res.send("ITEM UPDATED");
      });

    });

  });
  
  /*A DELETE request to /api should delete the entire collection. The API should return the
response “COLLECTION DELETED”.*/

app.delete("/api", 
  function(req,res)
  {
  	console.log("DELETE REQUEST RECEIVED");

    db.run("DELETE FROM Collection");
    res.send("COLLECTION DELETED");
  });

/*A DELETE request to /api/id should delete the item in the collection with the supplied id.
The API should return the response “ITEM DELETED”*/

app.delete("/api/:id", 
  function(req,res)
  {
  	console.log("DELETE REQUEST RECEIVED");
    db.run("DELETE FROM Collection WHERE rowid=" + req.params.id);
    res.send("COLLECTION DELETED");
  });
  
  
/*A POST request to /api should insert into the collection the item provided as JSON data
in the body of the request. The API should return the response “ITEM INSERTED”.*/

app.post("/api",
  function(req,res)
  {
  	console.log("POST REQUEST RECEIVED");

    var str = "";
    req.on("data", function(chunk) { str += chunk;});
    req.on("end", function() { 
 
      var reqObj = JSON.parse(str);

      console.log(str);

      db.serialize(function() {
        var stmt = db.prepare("INSERT INTO Collection (item, description, price)  VALUES (?,?,?)");
        stmt.run(reqObj.item,
        	     reqObj.description,
        	     reqObj.price);

        stmt.finalize();

        res.send("ITEM INSERTED");
      });

    });

  }); 


var server = app.listen(3000, function(){
  console.log("RESTful API listening on port 3000!")
});




















